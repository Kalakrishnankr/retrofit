package com.example.inspire.myapp;

/**
 * Created by inspire on 20/05/2017.
 */

public class Employeelist {
    String name;
    String lname;
    String dob;
    String doj;
    String department;
    String position;
    String salary;
    String usernm;
    String passwd;

    public Employeelist(String name,String lname,String dob,String doj,String department,String position,String salary,String usernm,String passwd){
        this.name = name;
        this.lname = lname;
        this.dob = dob;
        this.doj= doj;
        this.department=department;
        this.position=position;
        this.salary=salary;
        this.usernm=usernm;
        this.passwd=passwd;

    }


}
